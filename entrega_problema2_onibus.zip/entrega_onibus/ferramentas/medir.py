import argparse, csv, re, subprocess, sys, statistics, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description="Mede processos da Fase 1/3 com as cargas geradas; os tempos são locais.")
 p.add_argument("--repeticoes",type=int,default=5);p.add_argument("--n",type=int,nargs="+",default=[1000,5000,20000]);p.add_argument("--saida",default="resultados/medicoes.csv");a=p.parse_args()
 destino=ROOT/a.saida;destino.parent.mkdir(parents=True,exist_ok=True);rows=[]
 for n in a.n:
  for modo in ("ordem","embaralhado"):
   arquivo=ROOT/f"dados/sintetica_{modo}_{n}.txt"
   subprocess.run([sys.executable,str(ROOT/"ferramentas/gerar_cargas.py"),"--n",str(n),"--modo",modo,"--saida",str(arquivo)],check=True)
   for fase in (1,3):
    tempos=[];alturas=[]
    for _ in range(a.repeticoes):
     r=subprocess.run([sys.executable,str(ROOT/f"fase{fase}/sistema.py"),str(arquivo)],capture_output=True,text=True,check=True)
     m=re.search(r"TEMPO_MS ([0-9]+\.[0-9]{3})",r.stderr)
     if not m:raise RuntimeError(f"Fase {fase}: não foi encontrado TEMPO_MS: {r.stderr}")
     tempos.append(float(m.group(1)))
     # Consulta ALT separada, para não incluir seu custo na mediana das cargas REG.
     with arquivo.open("a",encoding="utf-8") as f:f.write("ALT\n")
     try:
      rh=subprocess.run([sys.executable,str(ROOT/f"fase{fase}/sistema.py"),str(arquivo)],capture_output=True,text=True,check=True)
      alturas.append(int(rh.stdout.strip().splitlines()[-1]))
     finally:
      linhas=arquivo.read_text(encoding="utf-8").splitlines();linhas.pop();arquivo.write_text("\n".join(linhas)+"\n",encoding="utf-8")
    rows.append([n,modo,fase,a.repeticoes,statistics.median(tempos),alturas[-1]])
    print(f"N={n} modo={modo} fase={fase}: mediana={statistics.median(tempos):.3f} ms; altura={alturas[-1]}",flush=True)
 with destino.open("w",newline="",encoding="utf-8") as f:
  w=csv.writer(f);w.writerow(["N","ordem","fase","repeticoes","mediana_ms","altura_final"]);w.writerows(rows)
 print(f"CSV: {destino}")
if __name__=="__main__":main()
