"""Microbenchmark de R4/R8: construção fora do cronômetro, consultas puras cronometradas."""
import argparse,statistics,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from comum import parse_arquivo,instante
from fase1.sistema import ABB
from fase3.sistema import Sistema,AVL

def main():
 p=argparse.ArgumentParser(description="Mede PROXL/SEMANA repetidos sobre o estado final dos REG de uma carga.")
 p.add_argument("arquivo");p.add_argument("--fase",type=int,choices=[1,3],required=True)
 p.add_argument("--repeticoes",type=int,default=1000);p.add_argument("--rodadas",type=int,default=5)
 p.add_argument("--linha",default="ZZZZ",help="linha de prova; ZZZZ força caso sem ocorrência")
 p.add_argument("--k",type=int,default=4)
 p.add_argument("--r8-principal-sem-indice",action="store_true",help="fase 3: mede SEMANA usando somente a AVL principal")
 a=p.parse_args()
 if a.r8_principal_sem_indice and a.fase!=3:raise SystemExit("--r8-principal-sem-indice exige --fase 3")
 ops=parse_arquivo(a.arquivo)
 somente_principal=a.r8_principal_sem_indice
 sistema=ABB() if a.fase==1 else (AVL() if somente_principal else Sistema())
 menor=None;registros=0
 for numero,c in ops:
  op=c[0].upper()
  if op not in ("REG","REM"):continue
  sec=instante(c[1],c[2]);k=(sec,c[3])
  if op=="REG":
   menor=sec if menor is None or sec<menor else menor
   ok=sistema.inserir(k) if a.fase==1 else (sistema.inserir(k,k) if somente_principal else sistema.inserir(k))
   if ok:registros+=1
  else:
   ok=sistema.remover(k) if a.fase==1 else sistema.remover(k)
   if ok:registros-=1
 if menor is None:raise SystemExit("Arquivo sem operações REG")
 dia,tod=divmod(menor,86400)
 def r4():
  for _ in range(a.repeticoes):
   if a.fase==1:sistema.proxima_linha(menor,a.linha)
   else:sistema.proxima_linha(menor,a.linha)
 def r8():
  for _ in range(a.repeticoes):
   for i in range(a.k-1,-1,-1):
    sec=(dia-7*i)*86400+tod
    if somente_principal:
     fim=(sec//86400+1)*86400
     for no in sistema.a_partir((sec,"")):
      if no.chave[0]>=fim:break
      if no.chave[1]==a.linha:break
    elif a.fase==1:sistema.proxima_linha_dia(sec,a.linha)
    else:sistema.proxima_linha_dia(sec,a.linha)
 med=[]
 consultas=(("SEMANA_PRINCIPAL",r8,a.repeticoes*a.k),) if somente_principal else (("PROXL",r4,a.repeticoes),("SEMANA",r8,a.repeticoes*a.k))
 for nome,fn,num in consultas:
  tempos=[]
  fn() # aquecimento, não incluído
  for _ in range(a.rodadas):
   t=time.perf_counter();fn();tempos.append((time.perf_counter()-t)*1000)
  m=statistics.median(tempos)
  med.append((nome,tempos,m,m/num))
 print(f"ARQUIVO {Path(a.arquivo).resolve()}")
 print(f"FASE {a.fase} REG_ATIVOS {registros} LINHA {a.linha} REPETICOES {a.repeticoes} RODADAS {a.rodadas} K {a.k} R8_SEM_INDICE {somente_principal}")
 for nome,tempos,m,por in med:
  print(f"{nome}_RODADAS_MS "+",".join(f"{x:.3f}" for x in tempos))
  print(f"{nome}_MEDIANA_MS {m:.3f} POR_CONSULTA_MS {por:.6f}")
 print("Escopo: árvore construída aplicando REG e REM antes do cronômetro; conversão/parsing excluídos; cronometrado somente o laço de buscas. R8_PRINCIPAL_SEM_INDICE percorre o intervalo do dia em ordem na AVL principal e filtra a linha, sem índice auxiliar.")
if __name__=="__main__":main()
