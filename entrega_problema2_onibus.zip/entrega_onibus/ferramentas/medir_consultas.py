import argparse,statistics,subprocess,sys,re,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rodar(fase,arquivo):
 r=subprocess.run([sys.executable,str(ROOT/f"fase{fase}/sistema.py"),str(arquivo)],capture_output=True,text=True,check=True)
 m=re.search(r"TEMPO_MS ([0-9]+\.[0-9]{3})",r.stderr)
 if not m:raise RuntimeError(f"TEMPO_MS ausente: {r.stderr}")
 return float(m.group(1))
def main():
 p=argparse.ArgumentParser(description="Estima tempo incremental de PROXL ou SEMANA em carga completa.")
 p.add_argument("arquivo");p.add_argument("--fase",type=int,choices=[1,3],required=True)
 p.add_argument("--operacao",choices=["PROXL","SEMANA"],required=True)
 p.add_argument("--extras",type=int,default=200);p.add_argument("--repeticoes",type=int,default=5)
 p.add_argument("--mediana-base",type=float,default=None,help="mediana previamente medida da carga original")
 p.add_argument("--linha-probe",default=None,help="sobrescreve a linha consultada (ex.: ZZZZ para cenário ausente/pior caso)")
 a=p.parse_args();src=Path(a.arquivo).resolve()
 linhas=src.read_text(encoding="utf-8").splitlines()
 qs=[s for s in linhas if s.strip() and not s.lstrip().startswith("#") and s.strip().split()[0].upper()==a.operacao]
 if not qs:raise SystemExit(f"Nenhuma operação {a.operacao} encontrada em {src}")
 extras=[]
 for i in range(a.extras):
  c=qs[i%len(qs)].split()
  if a.linha_probe is not None:c[3 if a.operacao=="PROXL" else 1]=a.linha_probe
  extras.append(" ".join(c))
 base=[];plus=[]
 if a.mediana_base is None:
  for _ in range(a.repeticoes):base.append(rodar(a.fase,src))
 with tempfile.TemporaryDirectory() as td:
  dest=Path(td)/"carga_consultas.txt"
  dest.write_text("\n".join(linhas+extras)+"\n",encoding="utf-8")
  for _ in range(a.repeticoes):plus.append(rodar(a.fase,dest))
 med_base=a.mediana_base if a.mediana_base is not None else statistics.median(base)
 med_plus=statistics.median(plus);delta=med_plus-med_base
 print(f"ARQUIVO {src}")
 print(f"FASE {a.fase} OPERACAO {a.operacao} REPETICOES {a.repeticoes}")
 print(f"CONSULTAS_EXTRAS {len(extras)}")
 if a.linha_probe is not None:print(f"LINHA_PROBE {a.linha_probe}")
 print("TEMPOS_BASE_MS "+(",".join(f"{x:.3f}" for x in base) if base else "reutilizada"))
 print("TEMPOS_AUGMENTADO_MS "+",".join(f"{x:.3f}" for x in plus))
 print(f"MEDIANA_BASE_MS {med_base:.3f}")
 print(f"MEDIANA_AUGMENTADO_MS {med_plus:.3f}")
 print(f"DELTA_MEDIANO_MS {delta:.3f}")
 print(f"DELTA_APROX_POR_CONSULTA_MS {delta/a.extras:.6f}")
 print("Nota: delta subtrai duas medianas de execuções completas; inclui parsing e construção da saída das consultas extras, sendo uma estimativa do custo incremental.")
if __name__=="__main__":main()
