"""Estima alocações Python retidas pelas estruturas; exclui runtime, arquivo e respostas."""
import argparse, importlib.util, sys, tracemalloc
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from comum import instante, parse_arquivo

def carregar_modulo(fase):
    caminho=ROOT/f"fase{fase}/sistema.py"
    spec=importlib.util.spec_from_file_location(f"sistema_fase{fase}",caminho)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def main():
    p=argparse.ArgumentParser(description="Mede memória retida dos nós após registros REG.")
    p.add_argument("fase",type=int,choices=[1,3]);p.add_argument("arquivo")
    a=p.parse_args();mod=carregar_modulo(a.fase);ops=parse_arquivo(a.arquivo)
    tracemalloc.start()
    sistema=mod.ABB() if a.fase==1 else mod.Sistema();n=0
    for numero,c in ops:
        op=c[0].upper()
        if op not in ("REG","REM"):continue
        k=(instante(c[1],c[2]),c[3])
        if op=="REG":
            ok=sistema.inserir(k) if a.fase==1 else sistema.inserir(k)
            if ok:n+=1
        else:
            ok=sistema.remover(k) if a.fase==1 else sistema.remover(k)
            if ok:n-=1
    atual,pico=tracemalloc.get_traced_memory();tracemalloc.stop()
    print(f"FASE {a.fase} n={n} RETIDO_BYTES={atual} PICO_BYTES={pico}")
    print("Escopo: alocações rastreadas após o início da medição no estado final; REG e REM aplicados; não inclui intérprete, parsing/lista de operações nem saída.")
if __name__=="__main__":main()
