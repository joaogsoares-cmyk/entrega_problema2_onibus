import argparse, re, statistics, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description="Repete a execução de uma carga existente e consulta ALT separadamente.")
    p.add_argument("arquivo",help="arquivo de operações, oficial ou de teste")
    p.add_argument("--fase",type=int,choices=[1,3],required=True)
    p.add_argument("--repeticoes",type=int,default=5)
    a=p.parse_args();arquivo=Path(a.arquivo).resolve()
    if not arquivo.is_file():raise SystemExit(f"Arquivo não encontrado: {arquivo}")
    tempos=[]
    for _ in range(a.repeticoes):
        r=subprocess.run([sys.executable,str(ROOT/f"fase{a.fase}/sistema.py"),str(arquivo)],capture_output=True,text=True,check=True)
        m=re.search(r"TEMPO_MS ([0-9]+\.[0-9]{3})",r.stderr)
        if not m:raise RuntimeError(f"TEMPO_MS não encontrado: {r.stderr}")
        tempos.append(float(m.group(1)))
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td)/"altura.txt"
        with arquivo.open("r",encoding="utf-8") as src, tmp.open("w",encoding="utf-8") as dst:
            dst.write(src.read())
            dst.write("\nALT\n")
        rh=subprocess.run([sys.executable,str(ROOT/f"fase{a.fase}/sistema.py"),str(tmp)],capture_output=True,text=True,check=True)
        altura=int(rh.stdout.strip().splitlines()[-1])
    print(f"ARQUIVO {arquivo}")
    print(f"FASE {a.fase} REPETICOES {a.repeticoes}")
    print("TEMPOS_MS " + ",".join(f"{x:.3f}" for x in tempos))
    print(f"MEDIANA_MS {statistics.median(tempos):.3f}")
    print(f"ALTURA_FINAL {altura}")
if __name__=="__main__":main()
