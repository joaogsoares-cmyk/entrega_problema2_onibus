import argparse, random
from datetime import date, timedelta
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description="Gera cargas sintéticas de REG; não substitui os arquivos oficiais do curso.")
 p.add_argument("--n",type=int,required=True);p.add_argument("--modo",choices=["ordem","embaralhado"],required=True);p.add_argument("--saida",required=True);p.add_argument("--semente",type=int,default=2026)
 a=p.parse_args(); itens=[]; inicio=date(2026,1,1).toordinal()*86400
 for i in range(a.n):
  s=inicio+i; ordinal,resto=divmod(s,86400);d=date.fromordinal(ordinal);hh,resto=divmod(resto,3600);mm,ss=divmod(resto,60)
  itens.append(f"REG {d.isoformat()} {hh:02d}:{mm:02d}:{ss:02d} 136.1")
 if a.modo=="embaralhado":random.Random(a.semente).shuffle(itens)
 Path(a.saida).parent.mkdir(parents=True,exist_ok=True);Path(a.saida).write_text("\n".join(itens)+"\n",encoding="utf-8")
if __name__=="__main__":main()
