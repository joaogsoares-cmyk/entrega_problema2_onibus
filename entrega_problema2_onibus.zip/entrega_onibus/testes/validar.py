from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
for fase in (1,3):
 r=subprocess.run([sys.executable,str(root/f"fase{fase}/sistema.py"),str(root/"testes/casos.txt")],capture_output=True,text=True,check=True)
 esperado=(root/f"testes/esperado_fase{fase}.txt").read_text(encoding="utf-8")
 if r.stdout!=esperado:raise SystemExit(f"Fase {fase}: saída diferente do esperado\nEsperado:\n{esperado}\nObtido:\n{r.stdout}")
 if "TEMPO_MS " not in r.stderr:raise SystemExit(f"Fase {fase}: TEMPO_MS não encontrado")
 print(f"Fase {fase}: OK")
