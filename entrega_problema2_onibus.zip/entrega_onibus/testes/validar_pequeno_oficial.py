from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
data=ROOT/"dados/oficial"
for fase in (1,3):
    entrada=data/"pequeno.txt"
    esperado=(data/f"pequeno_esperado_fase{fase}.txt").read_text(encoding="utf-8")
    r=subprocess.run([sys.executable,str(ROOT/f"fase{fase}/sistema.py"),str(entrada)],capture_output=True,text=True,check=True)
    if r.stdout!=esperado:
        raise SystemExit(f"Fase {fase}: divergência do gabarito oficial.\nEsperado:\n{esperado}\nObtido:\n{r.stdout}")
    if "TEMPO_MS " not in r.stderr:
        raise SystemExit(f"Fase {fase}: TEMPO_MS ausente em stderr")
    print(f"Arquivo pequeno oficial — Fase {fase}: OK")
