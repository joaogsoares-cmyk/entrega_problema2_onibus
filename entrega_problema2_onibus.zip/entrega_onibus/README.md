# Problema 2 — A que horas passa o próximo ônibus?

Implementação acadêmica em Python das Fases 1 e 3. O núcleo foi escrito com nós próprios: ABB na Fase 1; AVL principal e AVL auxiliar indexada por linha na Fase 3. Não são usados `dict`, `set`, `sorted`, `.sort()`, `bisect` ou árvores prontas no núcleo. Os vetores simples e bibliotecas de data/hora da biblioteca padrão são usados apenas para leitura, representação de dados e conversão de datas.

> **Importante:** `dados/oficial/` contém o arquivo curto, gabaritos e seis cargas oficiais usados no relatório. As medições do artigo foram feitas em sandbox cloud e o ambiente está informado; repita-as no computador do grupo caso a docente exija números daquele equipamento.

## Requisitos

Python 3.10 ou superior; nenhuma dependência externa. Execute a partir da raiz do repositório.

## Execução da entrega

O arquivo `executar.txt` contém, em três linhas, os comandos exigidos:

1. `-` (não há compilação);
2. `python fase1/sistema.py {arquivo}`;
3. `python fase3/sistema.py {arquivo}`.

No Windows, se `python` não estiver no PATH, substitua-o por `py -3`, mantendo `{arquivo}` como argumento. Exemplo no PowerShell:

```powershell
python fase3/sistema.py testes\casos.txt
```

As respostas vão para a saída padrão e `TEMPO_MS ...` vai para a saída de erro. O parser ignora linhas vazias e comentários iniciados por `#`.

## Teste funcional rápido

```powershell
python testes/validar.py
python fase1/sistema.py testes\casos.txt
python fase3/sistema.py testes\casos.txt
```

As respostas diferem legitimamente em `ALT`, porque a forma/altura das árvores pode ser diferente. Compare as demais linhas. Esse teste sintético cobre chegada duplicada, busca, PROX, PROXL, ENTRE, SEMANA, remoção e caso sem resultado. Para comparar o arquivo oficial curto com os gabaritos recebidos, execute `python testes/validar_pequeno_oficial.py`.

## Medições da Fase 2 e comparação

Para gerar uma matriz sintética de cargas de 1.000, 5.000 e 20.000 inserções, em ordem e embaralhadas, e executar cada combinação cinco vezes:

```powershell
python ferramentas/medir.py
```

O script grava `resultados/medicoes.csv`. Para testar somente tamanhos menores durante o desenvolvimento:

```powershell
python ferramentas/medir.py --n 100 500 --repeticoes 2
```

Os arquivos oficiais estão em `dados/oficial/`. Para executar cada carga na Fase 1 (repita com `--fase 3`):

```powershell
python ferramentas/medir_arquivo.py "dados\oficial\carga_quase_ordem_1000.txt" --fase 1
python ferramentas/medir_arquivo.py "dados\oficial\carga_quase_ordem_5000.txt" --fase 1
python ferramentas/medir_arquivo.py "dados\oficial\carga_quase_ordem_20000.txt" --fase 1
python ferramentas/medir_arquivo.py "dados\oficial\carga_embaralhada_1000.txt" --fase 1
python ferramentas/medir_arquivo.py "dados\oficial\carga_embaralhada_5000.txt" --fase 1
python ferramentas/medir_arquivo.py "dados\oficial\carga_embaralhada_20000.txt" --fase 1
```

Repita a mesma lista com `--fase 3`. Cada execução imprime os cinco tempos, a mediana e a altura, medida em uma execução separada para não contaminar o tempo. Copie os dados para as Tabelas 1–3 do relatório e calcule as razões N=20.000/N=1.000 para cada ordem.

Para medir alocação retida pelas estruturas na mesma carga (rode para fase 1 e fase 3):

```powershell
python ferramentas/memoria.py 1 caminho\carga.txt
python ferramentas/memoria.py 3 caminho\carga.txt
```

A ferramenta usa `tracemalloc`; informa bytes retidos e pico, excluindo intérprete, parsing/arquivo e saída. Use a mesma carga e versão de Python nas duas fases.

Para isolar R4 e R8 no estado final de uma carga (500 chamadas por rodada, quatro semanas por `SEMANA`, construção fora do cronômetro), rode:

```powershell
python ferramentas/medir_consulta_estruturas.py "dados\oficial\carga_quase_ordem_1000.txt" --fase 1
python ferramentas/medir_consulta_estruturas.py "dados\oficial\carga_quase_ordem_20000.txt" --fase 1
python ferramentas/medir_consulta_estruturas.py "dados\oficial\carga_quase_ordem_1000.txt" --fase 3
python ferramentas/medir_consulta_estruturas.py "dados\oficial\carga_quase_ordem_20000.txt" --fase 3
```

O teste usa a linha ausente `ZZZZ` para provocar a varredura de pior caso na ABB. Para verificar o impacto da linha existente, passe `--linha 136.1` (ou outra linha do conjunto). O resultado é um microbenchmark das buscas, não substitui o tempo da execução completa.

Para reproduzir especificamente a alternativa de R8 sem estrutura auxiliar por linha, execute a Fase 3 com `--r8-principal-sem-indice`. O ensaio constrói somente a AVL principal, mede o percurso da janela diária e filtra a linha; isso permite comparar o tempo com R8 usando o índice secundário.

As medições usadas nas tabelas estão arquivadas em `resultados/oficiais_resumo.csv`, `resultados/oficiais_tempos_brutos.csv`, `resultados/microconsultas_r4_r8.csv` e `resultados/r8_avl_principal_sem_indice.csv`.

Para criar uma carga individual (não oficial):

```powershell
python ferramentas/gerar_cargas.py --n 1000 --modo ordem --saida dados/exemplo.txt
```

**Reprodutibilidade:** rode os comandos equivalentes nas cargas oficiais e guarde as cinco medições brutas por execução. Informe CPU, memória, sistema operacional, versão exata do Python, condição de energia e se havia outros processos. Reporte mediana, altura após `ALT` e memória medida com o mesmo método para ambas as fases. Não compare os tempos gerados em máquinas diferentes como se fossem medidas controladas.

## Decisões e complexidades

A chave é `(segundos_desde_ordinal, código_da_linha)`. O primeiro componente é inteiro obtido de ano-mês-dia e hora; o segundo desempata chegadas simultâneas pela ordem lexicográfica dos códigos. Duas linhas distintas podem compartilhar instante; mesma linha/instante produz chave duplicada. Não se usa texto de data/hora como chave de ordenação.

Na Fase 1, R4 percorre a ABB em ordem até achar a próxima chegada da linha, com custo O(h+s) e pior caso Θ(n). R8 limita cada busca ao mesmo dia da semana, com custo O(kh + Σdᵢ); o pior caso é O(kn), mas o percurso diário não examina necessariamente todo o histórico de meses. Na Fase 3 há uma AVL principal, que é a única árvore consultada por ALT, e um índice AVL por código de linha. Cada nó do índice de linhas guarda uma segunda AVL dos instantes daquela linha. R4 consulta duas árvores em O(log ℓ + log n_l), em que ℓ é o número de linhas cadastradas e n_l os registros daquela linha. R8 repete essa consulta k vezes: O(k(log ℓ + log n_l)). Inserções/remoções mantêm as duas estruturas sincronizadas. Uma chegada usa dois nós de AVL (mais O(ℓ) nós de índice no pior caso).

`altura()` da ABB percorre os nós em O(n); na AVL retorna a altura armazenada na raiz em O(1). A remoção da AVL usa sucessor em ordem e rebalanceia o caminho de retorno; R6 custa O(log n + log ℓ + log n_l) no pior caso, incluindo atualização dos índices.

## Arquivos

- `fase1/sistema.py`: ABB e operações R1–R8.
- `fase3/sistema.py`: AVL principal, AVL de linhas e AVL temporal por linha.
- `comum.py`: conversões/parsing compartilhados.
- `ferramentas/`: geração de cargas, benchmark, medição de memória e microbenchmark R4/R8.
- `testes/`: testes sintéticos e comparador do gabarito oficial curto.
- `relatorio/relatorio.md` e `relatorio/relatorio.docx`: relatório em formato de artigo. A falta de commits e dos registros das sessões está declarada explicitamente; não foram inventados hashes ou eventos históricos. As medições indicam que foram feitas no sandbox cloud.
- `resultados/`: medianas/alturas/memória, tempos brutos de cinco execuções e microbenchmarks R4/R8 em CSV.

## Preparação e envio ao GitHub

1. Descompacte o ZIP em uma pasta sem acentos no caminho, por exemplo `C:\Users\SeuNome\Documents\problema2-onibus`.
2. O relatório registra que ainda não há commits nem atas semanais disponíveis. Se esses materiais forem criados/recuperados antes do envio, atualize a tabela de decisões com as evidências verdadeiras. As figuras e medições oficiais estão incluídas.
3. Abra PowerShell nessa pasta e rode `git init` (se ainda não for um repositório), `git add .`, `git commit -m "Implementa sistema de chegadas de ônibus"`.
4. No GitHub, crie um repositório vazio, sem README/licença inicial, e copie a URL HTTPS.
5. No PowerShell rode `git branch -M main`, `git remote add origin URL_DO_REPOSITORIO` e `git push -u origin main`.
6. Para alterações posteriores, use `git add .`, `git commit -m "Descreve a alteração"` e `git push`.
7. Confira no GitHub que os arquivos estão na branch `main`. Não publique senhas/tokens nem dados pessoais; não faça commits em nome dos colegas. Cada integrante deve configurar sua própria identidade Git antes de commitar.

Se já existir repositório, não rode `git init` nem adicione outro `origin`: use o remoto existente e integre os arquivos sem sobrescrever o histórico.
