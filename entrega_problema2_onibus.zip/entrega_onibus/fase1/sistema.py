import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from comum import instante, data_hora, formatar_chegada, parse_arquivo, validar_formato

class No:
    __slots__ = ("chave", "esq", "dir")
    def __init__(self, chave): self.chave, self.esq, self.dir = chave, None, None

class ABB:
    def __init__(self): self.raiz = None
    def buscar(self, chave):
        n = self.raiz
        while n:
            if chave == n.chave: return n
            n = n.esq if chave < n.chave else n.dir
        return None
    def inserir(self, chave):
        if self.raiz is None: self.raiz = No(chave); return True
        n = self.raiz
        while True:
            if chave == n.chave: return False
            lado = "esq" if chave < n.chave else "dir"
            prox = getattr(n, lado)
            if prox is None: setattr(n, lado, No(chave)); return True
            n = prox
    def remover(self, chave):
        pai, n = None, self.raiz
        while n and n.chave != chave:
            pai = n; n = n.esq if chave < n.chave else n.dir
        if n is None: return False
        if n.esq and n.dir:
            pp, suc = n, n.dir
            while suc.esq: pp, suc = suc, suc.esq
            n.chave = suc.chave
            if pp is n: pp.dir = suc.dir
            else: pp.esq = suc.dir
            return True
        filho = n.esq if n.esq else n.dir
        if pai is None: self.raiz = filho
        elif pai.esq is n: pai.esq = filho
        else: pai.dir = filho
        return True
    def altura(self):
        if not self.raiz: return 0
        maximo, pilha = 0, [(self.raiz, 1)]
        while pilha:
            n, h = pilha.pop(); maximo = max(maximo, h)
            if n.esq: pilha.append((n.esq, h+1))
            if n.dir: pilha.append((n.dir, h+1))
        return maximo
    def a_partir(self, chave):
        pilha, n = [], self.raiz
        while n:
            if n.chave >= chave: pilha.append(n); n = n.esq
            else: n = n.dir
        while pilha:
            atual = pilha.pop(); yield atual.chave
            n = atual.dir
            while n: pilha.append(n); n = n.esq
    def entre(self, a, b):
        if a > b: return []
        resultado = []
        for k in self.a_partir((a, "")):
            if k[0] > b: break
            resultado.append(k)
        return resultado
    def proxima_linha_dia(self, sec, linha):
        fim_dia = (sec // 86400 + 1) * 86400
        for k in self.a_partir((sec, "")):
            if k[0] >= fim_dia: break
            if k[1] == linha: return k[0]
        return None
    def proxima_linha(self, sec, linha):
        for k in self.a_partir((sec, "")):
            if k[1] == linha: return k[0]
        return None
    def proxima_geral(self, sec):
        return next(self.a_partir((sec, "")), None)

def executar(caminho):
    ops = parse_arquivo(caminho); arv = ABB(); saida=[]
    inicio = time.perf_counter()
    for numero, c in ops:
        op = validar_formato(c, numero)
        if op == "ALT": saida.append(str(arv.altura())); continue
        if op == "REG" or op == "BUSCA" or op == "REM":
            k=(instante(c[1],c[2]),c[3])
            if op=="REG": saida.append("OK" if arv.inserir(k) else "DUPLICADO")
            elif op=="BUSCA": saida.append("ACHOU" if arv.buscar(k) else "NAO")
            else: saida.append("OK" if arv.remover(k) else "NAO")
        elif op=="PROX":
            k=arv.proxima_geral(instante(c[1],c[2])); saida.append(formatar_chegada(k) if k else "NENHUM")
        elif op=="PROXL":
            sec=instante(c[1],c[2]); prox=arv.proxima_linha(sec,c[3])
            if prox is None: saida.append("NENHUM")
            else:
                d,h=data_hora(prox); saida.append(f"{d} {h}")
        elif op=="ENTRE":
            a=instante(c[1],c[2]); b=instante(c[3],c[4]); r=arv.entre(a,b)
            saida.append(str(len(r))); saida.extend(formatar_chegada(k) for k in r)
        elif op=="SEMANA":
            linha=c[1]; ord_data=instante(c[2],c[3])//86400; k=int(c[4])
            if k < 0: raise ValueError(f"linha {numero}: k não pode ser negativo")
            semana=[]
            for i in range(k-1,-1,-1):
                dia=ord_data-7*i; sec=dia*86400+(instante(c[2],c[3])%86400)
                chegada=arv.proxima_linha_dia(sec,linha)
                d,_=data_hora(sec)
                semana.append(f"{d} {chegada-sec}" if chegada is not None else f"{d} NAOPASSOU")
            saida.extend(semana)
    decorrido=(time.perf_counter()-inicio)*1000
    sys.stdout.write("\n".join(saida)+("\n" if saida else ""))
    print(f"TEMPO_MS {decorrido:.3f}",file=sys.stderr)

if __name__=="__main__":
    if len(sys.argv)!=2: print("uso: python fase1/sistema.py {arquivo}",file=sys.stderr); sys.exit(2)
    executar(sys.argv[1])
