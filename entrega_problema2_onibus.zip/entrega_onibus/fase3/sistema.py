import sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from comum import instante, data_hora, formatar_chegada, parse_arquivo, validar_formato

class No:
    __slots__=("chave","valor","esq","dir","h")
    def __init__(self,k,v=None): self.chave,self.valor,self.esq,self.dir,self.h=k,v,None,None,1

def altura(n): return n.h if n else 0
def atualizar(n): n.h=1+max(altura(n.esq),altura(n.dir)); return n
def rot_dir(y):
    x=y.esq; t=x.dir; x.dir=y; y.esq=t; atualizar(y); return atualizar(x)
def rot_esq(x):
    y=x.dir; t=y.esq; y.esq=x; x.dir=t; atualizar(x); return atualizar(y)
def balancear(n):
    if not n: return None
    atualizar(n); fb=altura(n.esq)-altura(n.dir)
    if fb>1:
        if altura(n.esq.esq)<altura(n.esq.dir): n.esq=rot_esq(n.esq)
        return rot_dir(n)
    if fb < -1:
        if altura(n.dir.dir)<altura(n.dir.esq): n.dir=rot_dir(n.dir)
        return rot_esq(n)
    return n

class AVL:
    def __init__(self): self.raiz=None; self.n=0
    def buscar_no(self,k):
        x=self.raiz
        while x:
            if k==x.chave: return x
            x=x.esq if k<x.chave else x.dir
        return None
    def _ins(self,n,k,v):
        if not n: return No(k,v),True
        if k==n.chave: return n,False
        if k<n.chave: n.esq,ok=self._ins(n.esq,k,v)
        else: n.dir,ok=self._ins(n.dir,k,v)
        return (balancear(n),ok) if ok else (n,False)
    def inserir(self,k,v=None):
        self.raiz,ok=self._ins(self.raiz,k,v)
        if ok:self.n+=1
        return ok
    def _rem(self,n,k):
        if not n:return None,False
        if k<n.chave:n.esq,ok=self._rem(n.esq,k)
        elif k>n.chave:n.dir,ok=self._rem(n.dir,k)
        else:
            if not n.esq:return n.dir,True
            if not n.dir:return n.esq,True
            p=n.dir
            while p.esq:p=p.esq
            n.chave,n.valor=p.chave,p.valor
            n.dir,_=self._rem(n.dir,p.chave)
            return balancear(n),True
        return (balancear(n),True) if ok else (n,False)
    def remover(self,k):
        self.raiz,ok=self._rem(self.raiz,k)
        if ok:self.n-=1
        return ok
    def menor_igual_ou_maior(self,k):
        n=self.raiz; candidato=None
        while n:
            if n.chave>=k:candidato=n;n=n.esq
            else:n=n.dir
        return candidato
    def a_partir(self,k):
        pilha=[]; n=self.raiz
        while n:
            if n.chave>=k:pilha.append(n);n=n.esq
            else:n=n.dir
        while pilha:
            atual=pilha.pop();yield atual
            n=atual.dir
            while n:pilha.append(n);n=n.esq
    def intervalo(self,a,b):
        if a>b:return []
        r=[]
        for n in self.a_partir(a):
            if n.chave>b:break
            r.append(n.chave)
        return r
    def altura(self): return altura(self.raiz)

class Sistema:
    def __init__(self): self.principal=AVL(); self.linhas=AVL()
    def inserir(self,k):
        if not self.principal.inserir(k,k):return False
        no=self.linhas.buscar_no(k[1])
        if no is None:
            indice=AVL(); indice.inserir(k[0],k); self.linhas.inserir(k[1],indice)
        else:no.valor.inserir(k[0],k)
        return True
    def remover(self,k):
        if not self.principal.remover(k):return False
        no=self.linhas.buscar_no(k[1]); no.valor.remover(k[0])
        if no.valor.n==0:self.linhas.remover(k[1])
        return True
    def proxima_linha_dia(self,sec,linha):
        no=self.linhas.buscar_no(linha)
        if no is None:return None
        cand=no.valor.menor_igual_ou_maior(sec)
        if cand is None or cand.chave >= (sec//86400+1)*86400:return None
        return cand.chave
    def proxima_linha(self,sec,linha):
        no=self.linhas.buscar_no(linha)
        if no is None:return None
        cand=no.valor.menor_igual_ou_maior(sec)
        return cand.chave if cand else None
    def proxima(self,sec):
        n=self.principal.menor_igual_ou_maior((sec,""));return n.chave if n else None
    def entre(self,a,b):return self.principal.intervalo((a,""),(b,"\U0010ffff"*8))

def executar(caminho):
    ops=parse_arquivo(caminho); s=Sistema(); saida=[]
    inicio=time.perf_counter()
    for numero,c in ops:
        op=validar_formato(c,numero)
        if op=="ALT":saida.append(str(s.principal.altura()))
        elif op in ("REG","BUSCA","REM"):
            k=(instante(c[1],c[2]),c[3])
            if op=="REG":saida.append("OK" if s.inserir(k) else "DUPLICADO")
            elif op=="BUSCA":saida.append("ACHOU" if s.principal.buscar_no(k) else "NAO")
            else:saida.append("OK" if s.remover(k) else "NAO")
        elif op=="PROX":
            k=s.proxima(instante(c[1],c[2]));saida.append(formatar_chegada(k) if k else "NENHUM")
        elif op=="PROXL":
            sec=instante(c[1],c[2]); x=s.proxima_linha(sec,c[3])
            if x is None:saida.append("NENHUM")
            else:
                d,h=data_hora(x);saida.append(f"{d} {h}")
        elif op=="ENTRE":
            a=instante(c[1],c[2]);b=instante(c[3],c[4]);r=s.entre(a,b)
            saida.append(str(len(r)));saida.extend(formatar_chegada(k) for k in r)
        elif op=="SEMANA":
            linha=c[1]; data=c[2]; base=instante(data,c[3]); ord_data=base//86400; tod=base%86400;k=int(c[4])
            if k<0:raise ValueError(f"linha {numero}: k não pode ser negativo")
            for i in range(k-1,-1,-1):
                sec=(ord_data-7*i)*86400+tod;prox=s.proxima_linha_dia(sec,linha);d,_=data_hora(sec)
                saida.append(f"{d} {prox-sec}" if prox is not None else f"{d} NAOPASSOU")
    ms=(time.perf_counter()-inicio)*1000
    sys.stdout.write("\n".join(saida)+("\n" if saida else ""));print(f"TEMPO_MS {ms:.3f}",file=sys.stderr)

if __name__=="__main__":
    if len(sys.argv)!=2:print("uso: python fase3/sistema.py {arquivo}",file=sys.stderr);sys.exit(2)
    executar(sys.argv[1])
