"""Utilitários comuns. O núcleo usa somente nós próprios e listas; sem mapas/conjuntos/ordenação pronta."""
from datetime import date


def instante(data_txt: str, hora_txt: str) -> int:
    ano, mes, dia = map(int, data_txt.split("-"))
    hh, mm, ss = map(int, hora_txt.split(":"))
    return date(ano, mes, dia).toordinal() * 86400 + hh * 3600 + mm * 60 + ss


def data_hora(seg: int) -> tuple[str, str]:
    ordinal, resto = divmod(seg, 86400)
    d = date.fromordinal(ordinal)
    hh, resto = divmod(resto, 3600)
    mm, ss = divmod(resto, 60)
    return d.isoformat(), f"{hh:02d}:{mm:02d}:{ss:02d}"


def parse_linha(texto: str):
    texto = texto.strip()
    if not texto or texto.startswith("#"):
        return None
    return texto.split()


def formatar_chegada(chave):
    seg, linha = chave
    d, h = data_hora(seg)
    return f"{d} {h} {linha}"


def parse_arquivo(caminho: str):
    ops = []
    with open(caminho, "r", encoding="utf-8") as arq:
        for numero, bruto in enumerate(arq, 1):
            campos = parse_linha(bruto)
            if campos is not None:
                ops.append((numero, campos))
    return ops


def validar_formato(campos, numero):
    aridade = {"REG": 4, "BUSCA": 4, "PROX": 3, "PROXL": 4,
               "ENTRE": 5, "REM": 4, "ALT": 1, "SEMANA": 5}
    op = campos[0].upper()
    if op not in aridade or len(campos) != aridade[op]:
        raise ValueError(f"linha {numero}: operação ou quantidade de argumentos inválida")
    return op
